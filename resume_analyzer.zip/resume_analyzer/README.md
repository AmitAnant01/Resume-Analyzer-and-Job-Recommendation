# ResumeAI — Resume Analyzer + Job Recommender

A Flask web app that analyzes your resume and recommends best-fit jobs based on your skills.

## Features
- Upload PDF, DOCX, or TXT resume
- Resume score (0–100) with breakdown
- Detected skills (30+ ML/DS/Dev technologies)
- Section checker (Education, Skills, Projects, etc.)
- Improvement tips
- Top job recommendations with match percentage

## Setup

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run
python app.py
```

Open `http://127.0.0.1:5000` in your browser.

## Project Structure
```
resume_analyzer/
├── app.py               # Flask backend (routes + logic)
├── requirements.txt
├── templates/
│   └── index.html       # Single-page UI
├── static/
│   ├── css/style.css
│   └── js/main.js
└── uploads/             # Temp storage (auto-deleted after analysis)
```
